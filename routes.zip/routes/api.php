<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\FilmController;
use App\Http\Controllers\ActorController;
use App\Http\Controllers\CriticController;

// Films
Route::get('/films', [FilmController::class, 'index']);
Route::get('/films/{id}', [FilmController::class, 'show']);
Route::get('/films/{id}/actors', [FilmController::class, 'actors']);
Route::get('/films/{id}/critics', [FilmController::class, 'critics']);

// Actors
Route::get('/actors', [ActorController::class, 'index']);
Route::get('/actors/{id}', [ActorController::class, 'show']);
Route::get('/actors/{id}/films', [ActorController::class, 'films']);

// Critics
Route::post('/critics', [CriticController::class, 'store']);
Route::get('/critics/{id}', [CriticController::class, 'show']);